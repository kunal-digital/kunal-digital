import { useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Chatbot() {
  useEffect(() => {
    // Load the Mendable script
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/@mendable/search@0.0.205/dist/umd/mendable-bundle.min.js';
    script.onload = () => {
      // Initialize Mendable after script loads
      if (window.Mendable) {
        window.Mendable.initialize({
          anon_key: 'f9c66484-c2d1-4bd2-9f88-aa9961c8de59',
          type: "searchBar",
          elementId: "mendable-component"
        });
      }
    };
    document.head.appendChild(script);

    // Cleanup function to remove script when component unmounts
    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-light-gray">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="text-slate hover:text-navy">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-3xl font-bold navy">Kunal AI Chatbot</h1>
            <div className="w-32"></div> {/* Spacer for center alignment */}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-lg shadow-sm p-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-semibold navy mb-4">Ask Me Anything</h2>
            <p className="text-slate">
              Use this AI chatbot to ask questions about my background, experience, and expertise. 
              It's trained on my professional information and can help answer questions about my work at LinkedIn, 
              teaching at Berkeley HAAS, patents, and more.
            </p>
          </div>
          
          {/* Mendable Component Container */}
          <div id="mendable-component" className="w-full"></div>
        </div>
      </div>
    </div>
  );
}

// Add global type declaration for Mendable
declare global {
  interface Window {
    Mendable: {
      initialize: (config: {
        anon_key: string;
        type: string;
        elementId: string;
      }) => void;
    };
  }
}