import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Menu, X, ArrowDown, Download, ExternalLink, Mail, Globe, GraduationCap } from "lucide-react";
import { Link } from "wouter";
import profileImage from "@assets/2025-May - kunal profile photo picture_1752094692318.jpg";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [headerShadow, setHeaderShadow] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setHeaderShadow(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-light-gray text-dark-gray">
      {/* Header */}
      <header className={`bg-white sticky top-0 z-50 transition-shadow duration-200 ${headerShadow ? 'shadow-md' : 'shadow-sm'}`}>
        <nav className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold navy">Kunal</h1>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-6">
              <button 
                onClick={() => scrollToSection('about')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('education')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                Education
              </button>
              <Link href="/chatbot">
                <span className="text-slate hover:text-navy transition-colors duration-200 cursor-pointer">
                  Kunal-AI-Chatbot
                </span>
              </Link>
              <button 
                onClick={() => scrollToSection('employment')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                Experience
              </button>
              <button 
                onClick={() => scrollToSection('honors')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                Awards
              </button>
              <button 
                onClick={() => scrollToSection('patents')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                Patents
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="text-slate hover:text-navy transition-colors duration-200"
              >
                Contact
              </button>
            </div>
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-slate hover:text-navy"
              >
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
          
          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4">
              <div className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('about')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  About
                </button>
                <button 
                  onClick={() => scrollToSection('education')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  Education
                </button>
                <Link href="/chatbot">
                  <span className="text-slate hover:text-navy transition-colors duration-200 cursor-pointer text-left block">
                    Kunal-AI-Chatbot
                  </span>
                </Link>
                <button 
                  onClick={() => scrollToSection('employment')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  Experience
                </button>
                <button 
                  onClick={() => scrollToSection('honors')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  Awards
                </button>
                <button 
                  onClick={() => scrollToSection('patents')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  Patents
                </button>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="text-slate hover:text-navy transition-colors duration-200 text-left"
                >
                  Contact
                </button>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* Hero Section */}
      <section className="bg-white py-16 md:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold navy mb-6">Kunal</h1>
          <p className="text-xl md:text-2xl text-slate font-light max-w-2xl mx-auto">
            Software Engineering Leader & Educator
          </p>
          <div className="mt-8">
            <Button
              onClick={() => scrollToSection('about')}
              className="bg-navy hover:bg-navy text-white px-8 py-3 rounded-lg shadow-lg"
            >
              Learn More
              <ArrowDown className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 md:py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">About</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
              <div className="prose prose-lg max-w-none">
                <p className="text-slate leading-relaxed mb-6">
                  Kunal is passionate about growing leaders and helping them have an impact. He loves learning new things & teaching it in an easy to understand format. He teaches on weekends at Berkeley HAAS & shares his learnings online on Youtube.
                </p>
                <p className="text-slate leading-relaxed mb-6">
                  Professionally he is a software engineer by training and has worked at LinkedIn for most of his career where he grew his responsibilities from Software Engineer to Director. He has managed a team of 50+ engineers & several senior managers and has built both large scale consumer and enterprise applications used by millions of customers and users globally.
                </p>
                <p className="text-slate leading-relaxed">
                  He knows how to attract, retain & grow top talent at scale. He values hard work, commitment to excellence and runs his life on trust.
                </p>
              </div>
            </div>
            
            <div className="order-1 md:order-2 text-center">
              <div className="inline-block relative">
                <img 
                  src={profileImage} 
                  alt="Professional photo of Kunal" 
                  className="w-80 h-80 rounded-full object-cover shadow-lg mx-auto"
                />
                <div className="absolute inset-0 rounded-full ring-4 ring-navy ring-opacity-20"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Education</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="space-y-8">
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-xl md:text-2xl font-semibold navy">University of California, Berkeley</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2022</span>
                </div>
                <p className="text-slate mb-2">MBA, Haas School of Business</p>
                <p className="text-slate text-sm">Focus: Leadership, Strategy, and Innovation</p>
              </CardContent>
            </Card>
            
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-xl md:text-2xl font-semibold navy">University of Southern California</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2008</span>
                </div>
                <p className="text-slate mb-2">MS, Computer Science</p>
                <p className="text-slate text-sm">Specialization: Software Engineering and Systems</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Employment History Section */}
      <section id="employment" className="py-16 md:py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Employment History</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="space-y-8">
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-xl md:text-2xl font-semibold navy">Lecturer - HAAS School of Business</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2022 to now</span>
                </div>
                <p className="text-slate mb-2">University of California, Berkeley</p>
                <p className="text-slate text-sm">Teaching: Data Analytics, Leadership Communications, Macroeconomics & Strategy</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-xl md:text-2xl font-semibold navy">Director of Engineering - LinkedIn</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2010 to 2023 (13 years)</span>
                </div>
                <p className="text-slate mb-2">Career progression through promotions approximately every 3 years</p>
                <p className="text-slate text-sm">Joined as Software Engineer, advanced to Director level</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Honors and Awards Section */}
      <section id="honors" className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Honors & Awards</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="space-y-6">
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Cheit Award for Excellence in Teaching (GSI)</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2024</span>
                </div>
                <p className="text-slate text-sm">Undergraduate program</p>
              </CardContent>
            </Card>
            
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Cheit Award for Excellence in Teaching (GSI)</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2023</span>
                </div>
                <p className="text-slate text-sm">Executive MBA program</p>
              </CardContent>
            </Card>
            
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">"Student Always" Berkeley Defining Leadership Principles Award</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2022</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-light-gray shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Poets and Quants for Execs Best & Brightest Executive MBA</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2022</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="py-16 md:py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Certifications</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="space-y-6">
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Certificate, Business Dynamics - Systems thinking</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2019</span>
                </div>
                <p className="text-slate text-sm">MIT Sloan School of Management</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Conscious Business</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2015</span>
                </div>
                <p className="text-slate text-sm">LinkedIn</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg md:text-xl font-semibold navy">Situational Leadership 2</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2013</span>
                </div>
                <p className="text-slate text-sm">American Management Association</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Teaching Experience Section */}
      <section id="teaching" className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Teaching Experience</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="mb-8">
            <p className="text-center text-slate mb-8">Across EMBA and EWMBA programs</p>
            
            <div className="space-y-6">
              <Card className="bg-light-gray shadow-sm">
                <CardContent className="p-6 md:p-8">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                    <h3 className="text-lg md:text-xl font-semibold navy">GSI Leadership Communications</h3>
                    <span className="text-slate text-sm md:text-base mt-2 md:mt-0">Spring 2022 (online)</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-light-gray shadow-sm">
                <CardContent className="p-6 md:p-8">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                    <h3 className="text-lg md:text-xl font-semibold navy">GSI Data Analytics</h3>
                    <span className="text-slate text-sm md:text-base mt-2 md:mt-0">Fall 2022, Fall 2023</span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-light-gray shadow-sm">
                <CardContent className="p-6 md:p-8">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                    <h3 className="text-lg md:text-xl font-semibold navy">GSI Macroeconomics</h3>
                    <span className="text-slate text-sm md:text-base mt-2 md:mt-0">Summer 2022 and 2023</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
          
          <div className="text-center">
            <p className="text-slate text-sm">
              <span className="font-semibold navy">Teaching Interests:</span> Leadership Communication, Data Science & Data Analytics
            </p>
          </div>
        </div>
      </section>

      {/* Patents Section */}
      <section id="patents" className="py-16 md:py-20 bg-light-gray">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Patents & Publications</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="mb-8 text-center">
            <a 
              href="https://patents.justia.com/inventor/kunal-mukesh-cholera" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-navy hover:text-navy-dark transition-colors duration-200 font-semibold"
            >
              Full patent list →
            </a>
          </div>
          
          <div className="space-y-6">
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg font-semibold navy">Integrated GLMix and non-linear optimization architectures</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2023</span>
                </div>
                <p className="text-slate text-sm">Patent number: 11544595</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg font-semibold navy">Precedence-based fast and space-efficient ranking</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2021</span>
                </div>
                <p className="text-slate text-sm">Patent number: 10929411</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg font-semibold navy">Specialized user interfaces to increase user interactions</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2018</span>
                </div>
                <p className="text-slate text-sm">Publication: 20180322464</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white shadow-sm">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                  <h3 className="text-lg font-semibold navy">Personalized job postings based on member data</h3>
                  <span className="text-slate text-sm md:text-base mt-2 md:mt-0">2017</span>
                </div>
                <p className="text-slate text-sm">Publication: 20170154313</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Contact</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div className="text-center md:text-left">
              <h3 className="text-xl font-semibold navy mb-6">Get in Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-center md:justify-start">
                  <Mail className="navy mr-3 h-5 w-5" />
                  <a 
                    href="mailto:kunal_cholera@berkeley.edu" 
                    className="text-slate hover:text-navy transition-colors duration-200"
                  >
                    kunal_cholera@berkeley.edu
                  </a>
                </div>
                <div className="flex items-center justify-center md:justify-start">
                  <Globe className="navy mr-3 h-5 w-5" />
                  <a 
                    href="https://chatgpt.com" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-slate hover:text-navy transition-colors duration-200"
                  >
                    chatgpt.com
                  </a>
                </div>
                <div className="flex items-center justify-center md:justify-start">
                  <GraduationCap className="navy mr-3 h-5 w-5" />
                  <span className="text-slate">University of California, Berkeley</span>
                </div>
              </div>
            </div>
            
            <div className="text-center md:text-left">
              <h3 className="text-xl font-semibold navy mb-6">Professional Links</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-center md:justify-start">
                  <ExternalLink className="navy mr-3 h-5 w-5" />
                  <a href="#" className="text-slate hover:text-navy transition-colors duration-200">
                    LinkedIn Profile
                  </a>
                </div>
                <div className="flex items-center justify-center md:justify-start">
                  <ExternalLink className="navy mr-3 h-5 w-5" />
                  <a href="#" className="text-slate hover:text-navy transition-colors duration-200">
                    ORCID Profile
                  </a>
                </div>
                <div className="flex items-center justify-center md:justify-start">
                  <GraduationCap className="navy mr-3 h-5 w-5" />
                  <a href="#" className="text-slate hover:text-navy transition-colors duration-200">
                    Google Scholar
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Resume Section */}
      <section id="resume" className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-12">
            <h2 className="text-3xl md:text-4xl font-bold navy mb-4">Resume</h2>
            <div className="w-24 h-1 bg-navy mx-auto"></div>
          </div>
          
          <Card className="bg-light-gray shadow-sm">
            <CardContent className="p-8 md:p-12">
              <div className="max-w-2xl mx-auto">
                <h3 className="text-xl md:text-2xl font-semibold navy mb-4">Download My Resume</h3>
                <p className="text-slate mb-8">
                  Get a comprehensive overview of my software engineering leadership experience, educational background, and professional achievements.
                </p>
                
                <div className="space-y-4 md:space-y-0 md:space-x-4 md:flex md:justify-center">
                  <Button 
                    className="bg-navy hover:bg-navy text-white px-8 py-3 rounded-lg shadow-lg"
                    onClick={() => window.open('#', '_blank')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download Resume (PDF)
                  </Button>
                  
                  <Button 
                    variant="outline"
                    className="border-navy text-navy hover:bg-navy hover:text-white px-8 py-3 rounded-lg border-2"
                    onClick={() => window.open('#', '_blank')}
                  >
                    <ExternalLink className="mr-2 h-4 w-4" />
                    View Online
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy text-white py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-blue-200 mb-4">
              "Excellence in leadership through dedication, innovation, and collaborative spirit."
            </p>
            <p className="text-blue-300 text-sm">
              © 2024 Kunal. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
