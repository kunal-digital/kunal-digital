# Professional Personal Website for Haas

## Overview

This is a professional single-page personal website designed for Haas, a Berkeley-affiliated academic professional. The application serves as a digital introduction and academic profile, functioning as both an online resume and personal branding tool. It features a modern, clean design with academic styling, optimized for both desktop and mobile viewing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom academic color palette
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Development**: tsx for TypeScript execution in development
- **Production Build**: esbuild for server-side bundling

### Project Structure
The application follows a monorepo structure with clear separation of concerns:
- `client/` - Frontend React application
- `server/` - Backend Express server
- `shared/` - Shared TypeScript schemas and types
- `attached_assets/` - Static assets and images

## Key Components

### Frontend Components
1. **Home Page** (`client/src/pages/home.tsx`)
   - Single-page layout with smooth scrolling navigation
   - Professional header with sticky navigation
   - About section with bio and professional photo
   - Education section highlighting academic background
   - Contact section with email and external links
   - Resume download functionality

2. **UI Component Library**
   - Complete shadcn/ui component set for consistent design
   - Custom academic color scheme with navy blue primary colors
   - Responsive design components with mobile-first approach

3. **Navigation System**
   - Sticky header with shadow effects on scroll
   - Mobile-responsive hamburger menu
   - Smooth scroll-to-section functionality

### Backend Components
1. **Express Server** (`server/index.ts`)
   - Request logging middleware
   - Error handling middleware
   - Static file serving in production
   - Development-only Vite integration

2. **Storage Layer** (`server/storage.ts`)
   - Memory-based storage implementation
   - User management interface (prepared for future features)
   - Ready for database integration

3. **Route Management** (`server/routes.ts`)
   - Modular route registration system
   - API endpoint structure ready for expansion

## Data Flow

### Current Implementation
- **Static Content**: All content is currently hardcoded in the frontend components
- **Assets**: Professional photo and resume are referenced via external links (Google Drive)
- **No Database**: Currently uses in-memory storage for basic user management structure

### Future Scalability
- Database integration ready via Drizzle ORM configuration
- PostgreSQL support configured but not yet implemented
- API routes structured for future dynamic content management

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18 with TypeScript support
- **UI Framework**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS for utility-first styling
- **Database ORM**: Drizzle ORM with PostgreSQL dialect (configured)
- **Development Tools**: Vite, esbuild, tsx for development workflow

### External Integrations
- **Google Drive**: Used for hosting professional photo and resume
- **Email**: Direct mailto links for contact functionality
- **External Website**: Links to chatgpt.com as specified in requirements

### Database Configuration
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Connection**: Environment variable-based configuration
- **Migrations**: Automated migration system ready for deployment

## Deployment Strategy

### Development Environment
- **Local Development**: `npm run dev` starts both frontend and backend
- **Hot Reload**: Vite provides instant updates during development
- **Type Safety**: Full TypeScript support across the entire stack

### Production Build
- **Frontend**: Vite builds optimized static assets
- **Backend**: esbuild creates a single bundled server file
- **Static Serving**: Express serves built frontend assets

### Environment Configuration
- **Database**: Configured for PostgreSQL via DATABASE_URL environment variable
- **Development**: Automatic Vite integration in development mode
- **Production**: Optimized static file serving with proper caching

### Replit Integration
- **Development Banner**: Replit development banner for external access
- **Runtime Error Overlay**: Development-only error reporting
- **Cartographer Plugin**: Replit-specific development tools

The architecture supports easy migration from the current static implementation to a dynamic, database-driven system while maintaining the professional, academic aesthetic required for Haas's personal website.